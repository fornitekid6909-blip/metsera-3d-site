import { getStore } from "@netlify/blobs";

export default async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  const store = getStore({ name: "mestera-products", consistency: "strong" });

  if (req.method === "POST") {
    const body = await req.json();
    const { productId, review } = body;

    if (!productId || !review || !review.author || !review.text || !review.stars) {
      return Response.json({ error: "Date incomplete" }, { status: 400 });
    }

    // Validate stars
    if (review.stars < 1 || review.stars > 5) {
      return Response.json({ error: "Stele invalide" }, { status: 400 });
    }

    let products = await store.get("products", { type: "json" });
    if (!products) return Response.json({ error: "Produse negasite" }, { status: 404 });

    const idx = products.findIndex(p => p.id === productId);
    if (idx === -1) return Response.json({ error: "Produs negasit" }, { status: 404 });

    if (!products[idx].reviews) products[idx].reviews = [];
    products[idx].reviews.push({
      author: review.author,
      date: new Date().toLocaleDateString('ro-RO', { day: 'numeric', month: 'short', year: 'numeric' }),
      stars: review.stars,
      text: review.text.slice(0, 500), // max 500 chars
    });

    await store.setJSON("products", products);
    return Response.json({ ok: true, reviews: products[idx].reviews });
  }

  return Response.json({ error: "Method not allowed" }, { status: 405 });
};

export const config = { path: "/api/reviews" };
